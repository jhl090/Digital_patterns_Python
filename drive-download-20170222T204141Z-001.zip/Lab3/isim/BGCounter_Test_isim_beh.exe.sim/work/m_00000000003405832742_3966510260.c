/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//acsnfs4.ucsd.edu/CifsHomes/872/jhl090/140L/Lab3/BCD_Gray_Counter.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};
static int ng3[] = {2, 0};
static int ng4[] = {4, 0};
static int ng5[] = {7, 0};



static void Always_36_0(char *t0)
{
    char t6[8];
    char t35[8];
    char t41[8];
    char t57[8];
    char t65[8];
    char t92[8];
    char t109[8];
    char t125[8];
    char t133[8];
    char t161[8];
    char t178[8];
    char t194[8];
    char t202[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    int t33;
    char *t34;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    char *t42;
    char *t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    char *t56;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    char *t64;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    char *t69;
    char *t70;
    char *t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    char *t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    char *t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    char *t99;
    char *t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    char *t105;
    char *t106;
    char *t107;
    char *t108;
    char *t110;
    char *t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    char *t124;
    char *t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    unsigned int t131;
    char *t132;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    char *t137;
    char *t138;
    char *t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    char *t147;
    char *t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    int t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    char *t162;
    unsigned int t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    char *t168;
    char *t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    char *t174;
    char *t175;
    char *t176;
    char *t177;
    char *t179;
    char *t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    char *t193;
    char *t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    char *t201;
    unsigned int t203;
    unsigned int t204;
    unsigned int t205;
    char *t206;
    char *t207;
    char *t208;
    unsigned int t209;
    unsigned int t210;
    unsigned int t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    char *t216;
    char *t217;
    unsigned int t218;
    unsigned int t219;
    unsigned int t220;
    int t221;
    unsigned int t222;
    unsigned int t223;
    unsigned int t224;
    int t225;
    unsigned int t226;
    unsigned int t227;
    unsigned int t228;
    unsigned int t229;
    char *t230;
    unsigned int t231;
    unsigned int t232;
    unsigned int t233;
    unsigned int t234;
    unsigned int t235;
    char *t236;
    char *t237;
    char *t238;

LAB0:    t1 = (t0 + 3936U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 4256);
    *((int *)t2) = 1;
    t3 = (t0 + 3968);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(36, ng0);

LAB5:    xsi_set_current_line(37, ng0);
    t4 = (t0 + 2136U);
    t5 = *((char **)t4);
    t4 = ((char*)((ng1)));
    memset(t6, 0, 8);
    t7 = (t5 + 4);
    t8 = (t4 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t4);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB9;

LAB6:    if (t18 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t6) = 1;

LAB9:    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 != 0);
    if (t27 > 0)
        goto LAB10;

LAB11:    xsi_set_current_line(58, ng0);

LAB95:    xsi_set_current_line(59, ng0);
    t2 = (t0 + 3016);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);

LAB96:    t5 = (t0 + 472);
    t7 = *((char **)t5);
    t33 = xsi_vlog_unsigned_case_compare(t4, 3, t7, 32);
    if (t33 == 1)
        goto LAB97;

LAB98:    t2 = (t0 + 608);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t33 == 1)
        goto LAB99;

LAB100:    t2 = (t0 + 744);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t33 == 1)
        goto LAB101;

LAB102:    t2 = (t0 + 880);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t33 == 1)
        goto LAB103;

LAB104:    t2 = (t0 + 1016);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t33 == 1)
        goto LAB105;

LAB106:    t2 = (t0 + 1152);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t33 == 1)
        goto LAB107;

LAB108:    t2 = (t0 + 1288);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t33 == 1)
        goto LAB109;

LAB110:    t2 = (t0 + 1424);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t4, 3, t3, 32);
    if (t33 == 1)
        goto LAB111;

LAB112:
LAB114:
LAB113:    xsi_set_current_line(68, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);

LAB115:    xsi_set_current_line(71, ng0);
    t2 = (t0 + 3016);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t7 = (t0 + 2856);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 3);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 2856);
    t3 = (t2 + 56U);
    t5 = *((char **)t3);
    t7 = ((char*)((ng2)));
    memset(t6, 0, 8);
    t8 = (t5 + 4);
    t21 = (t7 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t7);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t8);
    t13 = *((unsigned int *)t21);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t8);
    t17 = *((unsigned int *)t21);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB119;

LAB116:    if (t18 != 0)
        goto LAB118;

LAB117:    *((unsigned int *)t6) = 1;

LAB119:    memset(t35, 0, 8);
    t28 = (t6 + 4);
    t23 = *((unsigned int *)t28);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB120;

LAB121:    if (*((unsigned int *)t28) != 0)
        goto LAB122;

LAB123:    t31 = (t35 + 4);
    t36 = *((unsigned int *)t35);
    t37 = (!(t36));
    t38 = *((unsigned int *)t31);
    t39 = (t37 || t38);
    if (t39 > 0)
        goto LAB124;

LAB125:    memcpy(t65, t35, 8);

LAB126:    memset(t92, 0, 8);
    t99 = (t65 + 4);
    t94 = *((unsigned int *)t99);
    t95 = (~(t94));
    t96 = *((unsigned int *)t65);
    t97 = (t96 & t95);
    t98 = (t97 & 1U);
    if (t98 != 0)
        goto LAB138;

LAB139:    if (*((unsigned int *)t99) != 0)
        goto LAB140;

LAB141:    t105 = (t92 + 4);
    t101 = *((unsigned int *)t92);
    t102 = (!(t101));
    t103 = *((unsigned int *)t105);
    t104 = (t102 || t103);
    if (t104 > 0)
        goto LAB142;

LAB143:    memcpy(t133, t92, 8);

LAB144:    memset(t161, 0, 8);
    t168 = (t133 + 4);
    t163 = *((unsigned int *)t168);
    t164 = (~(t163));
    t165 = *((unsigned int *)t133);
    t166 = (t165 & t164);
    t167 = (t166 & 1U);
    if (t167 != 0)
        goto LAB156;

LAB157:    if (*((unsigned int *)t168) != 0)
        goto LAB158;

LAB159:    t174 = (t161 + 4);
    t170 = *((unsigned int *)t161);
    t171 = (!(t170));
    t172 = *((unsigned int *)t174);
    t173 = (t171 || t172);
    if (t173 > 0)
        goto LAB160;

LAB161:    memcpy(t202, t161, 8);

LAB162:    t236 = (t202 + 4);
    t231 = *((unsigned int *)t236);
    t232 = (~(t231));
    t233 = *((unsigned int *)t202);
    t234 = (t233 & t232);
    t235 = (t234 != 0);
    if (t235 > 0)
        goto LAB174;

LAB175:    xsi_set_current_line(75, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2696);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB176:
LAB12:    goto LAB2;

LAB8:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(37, ng0);

LAB13:    xsi_set_current_line(39, ng0);
    t28 = (t0 + 3016);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);

LAB14:    t31 = (t0 + 472);
    t32 = *((char **)t31);
    t33 = xsi_vlog_unsigned_case_compare(t30, 3, t32, 32);
    if (t33 == 1)
        goto LAB15;

LAB16:    t2 = (t0 + 608);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t30, 3, t3, 32);
    if (t33 == 1)
        goto LAB17;

LAB18:    t2 = (t0 + 744);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t30, 3, t3, 32);
    if (t33 == 1)
        goto LAB19;

LAB20:    t2 = (t0 + 880);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t30, 3, t3, 32);
    if (t33 == 1)
        goto LAB21;

LAB22:    t2 = (t0 + 1016);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t30, 3, t3, 32);
    if (t33 == 1)
        goto LAB23;

LAB24:    t2 = (t0 + 1152);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t30, 3, t3, 32);
    if (t33 == 1)
        goto LAB25;

LAB26:    t2 = (t0 + 1288);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t30, 3, t3, 32);
    if (t33 == 1)
        goto LAB27;

LAB28:    t2 = (t0 + 1424);
    t3 = *((char **)t2);
    t33 = xsi_vlog_unsigned_case_compare(t30, 3, t3, 32);
    if (t33 == 1)
        goto LAB29;

LAB30:
LAB32:
LAB31:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 472);
    t3 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 3, 0LL);

LAB33:    xsi_set_current_line(51, ng0);
    t2 = (t0 + 3016);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2856);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 3);
    xsi_set_current_line(53, ng0);
    t2 = (t0 + 2856);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    memset(t6, 0, 8);
    t7 = (t4 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t4);
    t10 = *((unsigned int *)t5);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t7);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t7);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB37;

LAB34:    if (t18 != 0)
        goto LAB36;

LAB35:    *((unsigned int *)t6) = 1;

LAB37:    memset(t35, 0, 8);
    t22 = (t6 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t6);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB38;

LAB39:    if (*((unsigned int *)t22) != 0)
        goto LAB40;

LAB41:    t29 = (t35 + 4);
    t36 = *((unsigned int *)t35);
    t37 = (!(t36));
    t38 = *((unsigned int *)t29);
    t39 = (t37 || t38);
    if (t39 > 0)
        goto LAB42;

LAB43:    memcpy(t65, t35, 8);

LAB44:    memset(t92, 0, 8);
    t93 = (t65 + 4);
    t94 = *((unsigned int *)t93);
    t95 = (~(t94));
    t96 = *((unsigned int *)t65);
    t97 = (t96 & t95);
    t98 = (t97 & 1U);
    if (t98 != 0)
        goto LAB56;

LAB57:    if (*((unsigned int *)t93) != 0)
        goto LAB58;

LAB59:    t100 = (t92 + 4);
    t101 = *((unsigned int *)t92);
    t102 = (!(t101));
    t103 = *((unsigned int *)t100);
    t104 = (t102 || t103);
    if (t104 > 0)
        goto LAB60;

LAB61:    memcpy(t133, t92, 8);

LAB62:    memset(t161, 0, 8);
    t162 = (t133 + 4);
    t163 = *((unsigned int *)t162);
    t164 = (~(t163));
    t165 = *((unsigned int *)t133);
    t166 = (t165 & t164);
    t167 = (t166 & 1U);
    if (t167 != 0)
        goto LAB74;

LAB75:    if (*((unsigned int *)t162) != 0)
        goto LAB76;

LAB77:    t169 = (t161 + 4);
    t170 = *((unsigned int *)t161);
    t171 = (!(t170));
    t172 = *((unsigned int *)t169);
    t173 = (t171 || t172);
    if (t173 > 0)
        goto LAB78;

LAB79:    memcpy(t202, t161, 8);

LAB80:    t230 = (t202 + 4);
    t231 = *((unsigned int *)t230);
    t232 = (~(t231));
    t233 = *((unsigned int *)t202);
    t234 = (t233 & t232);
    t235 = (t234 != 0);
    if (t235 > 0)
        goto LAB92;

LAB93:    xsi_set_current_line(55, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2696);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB94:    goto LAB12;

LAB15:    xsi_set_current_line(40, ng0);
    t31 = (t0 + 608);
    t34 = *((char **)t31);
    t31 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t31, t34, 0, 0, 3, 0LL);
    goto LAB33;

LAB17:    xsi_set_current_line(41, ng0);
    t2 = (t0 + 744);
    t4 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 3, 0LL);
    goto LAB33;

LAB19:    xsi_set_current_line(42, ng0);
    t2 = (t0 + 880);
    t4 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 3, 0LL);
    goto LAB33;

LAB21:    xsi_set_current_line(43, ng0);
    t2 = (t0 + 1016);
    t4 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 3, 0LL);
    goto LAB33;

LAB23:    xsi_set_current_line(44, ng0);
    t2 = (t0 + 1152);
    t4 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 3, 0LL);
    goto LAB33;

LAB25:    xsi_set_current_line(45, ng0);
    t2 = (t0 + 1288);
    t4 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 3, 0LL);
    goto LAB33;

LAB27:    xsi_set_current_line(46, ng0);
    t2 = (t0 + 1424);
    t4 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 3, 0LL);
    goto LAB33;

LAB29:    xsi_set_current_line(47, ng0);
    t2 = (t0 + 472);
    t4 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t4, 0, 0, 3, 0LL);
    goto LAB33;

LAB36:    t21 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB37;

LAB38:    *((unsigned int *)t35) = 1;
    goto LAB41;

LAB40:    t28 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB41;

LAB42:    t31 = (t0 + 2856);
    t32 = (t31 + 56U);
    t34 = *((char **)t32);
    t40 = ((char*)((ng3)));
    memset(t41, 0, 8);
    t42 = (t34 + 4);
    t43 = (t40 + 4);
    t44 = *((unsigned int *)t34);
    t45 = *((unsigned int *)t40);
    t46 = (t44 ^ t45);
    t47 = *((unsigned int *)t42);
    t48 = *((unsigned int *)t43);
    t49 = (t47 ^ t48);
    t50 = (t46 | t49);
    t51 = *((unsigned int *)t42);
    t52 = *((unsigned int *)t43);
    t53 = (t51 | t52);
    t54 = (~(t53));
    t55 = (t50 & t54);
    if (t55 != 0)
        goto LAB48;

LAB45:    if (t53 != 0)
        goto LAB47;

LAB46:    *((unsigned int *)t41) = 1;

LAB48:    memset(t57, 0, 8);
    t58 = (t41 + 4);
    t59 = *((unsigned int *)t58);
    t60 = (~(t59));
    t61 = *((unsigned int *)t41);
    t62 = (t61 & t60);
    t63 = (t62 & 1U);
    if (t63 != 0)
        goto LAB49;

LAB50:    if (*((unsigned int *)t58) != 0)
        goto LAB51;

LAB52:    t66 = *((unsigned int *)t35);
    t67 = *((unsigned int *)t57);
    t68 = (t66 | t67);
    *((unsigned int *)t65) = t68;
    t69 = (t35 + 4);
    t70 = (t57 + 4);
    t71 = (t65 + 4);
    t72 = *((unsigned int *)t69);
    t73 = *((unsigned int *)t70);
    t74 = (t72 | t73);
    *((unsigned int *)t71) = t74;
    t75 = *((unsigned int *)t71);
    t76 = (t75 != 0);
    if (t76 == 1)
        goto LAB53;

LAB54:
LAB55:    goto LAB44;

LAB47:    t56 = (t41 + 4);
    *((unsigned int *)t41) = 1;
    *((unsigned int *)t56) = 1;
    goto LAB48;

LAB49:    *((unsigned int *)t57) = 1;
    goto LAB52;

LAB51:    t64 = (t57 + 4);
    *((unsigned int *)t57) = 1;
    *((unsigned int *)t64) = 1;
    goto LAB52;

LAB53:    t77 = *((unsigned int *)t65);
    t78 = *((unsigned int *)t71);
    *((unsigned int *)t65) = (t77 | t78);
    t79 = (t35 + 4);
    t80 = (t57 + 4);
    t81 = *((unsigned int *)t79);
    t82 = (~(t81));
    t83 = *((unsigned int *)t35);
    t33 = (t83 & t82);
    t84 = *((unsigned int *)t80);
    t85 = (~(t84));
    t86 = *((unsigned int *)t57);
    t87 = (t86 & t85);
    t88 = (~(t33));
    t89 = (~(t87));
    t90 = *((unsigned int *)t71);
    *((unsigned int *)t71) = (t90 & t88);
    t91 = *((unsigned int *)t71);
    *((unsigned int *)t71) = (t91 & t89);
    goto LAB55;

LAB56:    *((unsigned int *)t92) = 1;
    goto LAB59;

LAB58:    t99 = (t92 + 4);
    *((unsigned int *)t92) = 1;
    *((unsigned int *)t99) = 1;
    goto LAB59;

LAB60:    t105 = (t0 + 2856);
    t106 = (t105 + 56U);
    t107 = *((char **)t106);
    t108 = ((char*)((ng4)));
    memset(t109, 0, 8);
    t110 = (t107 + 4);
    t111 = (t108 + 4);
    t112 = *((unsigned int *)t107);
    t113 = *((unsigned int *)t108);
    t114 = (t112 ^ t113);
    t115 = *((unsigned int *)t110);
    t116 = *((unsigned int *)t111);
    t117 = (t115 ^ t116);
    t118 = (t114 | t117);
    t119 = *((unsigned int *)t110);
    t120 = *((unsigned int *)t111);
    t121 = (t119 | t120);
    t122 = (~(t121));
    t123 = (t118 & t122);
    if (t123 != 0)
        goto LAB66;

LAB63:    if (t121 != 0)
        goto LAB65;

LAB64:    *((unsigned int *)t109) = 1;

LAB66:    memset(t125, 0, 8);
    t126 = (t109 + 4);
    t127 = *((unsigned int *)t126);
    t128 = (~(t127));
    t129 = *((unsigned int *)t109);
    t130 = (t129 & t128);
    t131 = (t130 & 1U);
    if (t131 != 0)
        goto LAB67;

LAB68:    if (*((unsigned int *)t126) != 0)
        goto LAB69;

LAB70:    t134 = *((unsigned int *)t92);
    t135 = *((unsigned int *)t125);
    t136 = (t134 | t135);
    *((unsigned int *)t133) = t136;
    t137 = (t92 + 4);
    t138 = (t125 + 4);
    t139 = (t133 + 4);
    t140 = *((unsigned int *)t137);
    t141 = *((unsigned int *)t138);
    t142 = (t140 | t141);
    *((unsigned int *)t139) = t142;
    t143 = *((unsigned int *)t139);
    t144 = (t143 != 0);
    if (t144 == 1)
        goto LAB71;

LAB72:
LAB73:    goto LAB62;

LAB65:    t124 = (t109 + 4);
    *((unsigned int *)t109) = 1;
    *((unsigned int *)t124) = 1;
    goto LAB66;

LAB67:    *((unsigned int *)t125) = 1;
    goto LAB70;

LAB69:    t132 = (t125 + 4);
    *((unsigned int *)t125) = 1;
    *((unsigned int *)t132) = 1;
    goto LAB70;

LAB71:    t145 = *((unsigned int *)t133);
    t146 = *((unsigned int *)t139);
    *((unsigned int *)t133) = (t145 | t146);
    t147 = (t92 + 4);
    t148 = (t125 + 4);
    t149 = *((unsigned int *)t147);
    t150 = (~(t149));
    t151 = *((unsigned int *)t92);
    t152 = (t151 & t150);
    t153 = *((unsigned int *)t148);
    t154 = (~(t153));
    t155 = *((unsigned int *)t125);
    t156 = (t155 & t154);
    t157 = (~(t152));
    t158 = (~(t156));
    t159 = *((unsigned int *)t139);
    *((unsigned int *)t139) = (t159 & t157);
    t160 = *((unsigned int *)t139);
    *((unsigned int *)t139) = (t160 & t158);
    goto LAB73;

LAB74:    *((unsigned int *)t161) = 1;
    goto LAB77;

LAB76:    t168 = (t161 + 4);
    *((unsigned int *)t161) = 1;
    *((unsigned int *)t168) = 1;
    goto LAB77;

LAB78:    t174 = (t0 + 2856);
    t175 = (t174 + 56U);
    t176 = *((char **)t175);
    t177 = ((char*)((ng5)));
    memset(t178, 0, 8);
    t179 = (t176 + 4);
    t180 = (t177 + 4);
    t181 = *((unsigned int *)t176);
    t182 = *((unsigned int *)t177);
    t183 = (t181 ^ t182);
    t184 = *((unsigned int *)t179);
    t185 = *((unsigned int *)t180);
    t186 = (t184 ^ t185);
    t187 = (t183 | t186);
    t188 = *((unsigned int *)t179);
    t189 = *((unsigned int *)t180);
    t190 = (t188 | t189);
    t191 = (~(t190));
    t192 = (t187 & t191);
    if (t192 != 0)
        goto LAB84;

LAB81:    if (t190 != 0)
        goto LAB83;

LAB82:    *((unsigned int *)t178) = 1;

LAB84:    memset(t194, 0, 8);
    t195 = (t178 + 4);
    t196 = *((unsigned int *)t195);
    t197 = (~(t196));
    t198 = *((unsigned int *)t178);
    t199 = (t198 & t197);
    t200 = (t199 & 1U);
    if (t200 != 0)
        goto LAB85;

LAB86:    if (*((unsigned int *)t195) != 0)
        goto LAB87;

LAB88:    t203 = *((unsigned int *)t161);
    t204 = *((unsigned int *)t194);
    t205 = (t203 | t204);
    *((unsigned int *)t202) = t205;
    t206 = (t161 + 4);
    t207 = (t194 + 4);
    t208 = (t202 + 4);
    t209 = *((unsigned int *)t206);
    t210 = *((unsigned int *)t207);
    t211 = (t209 | t210);
    *((unsigned int *)t208) = t211;
    t212 = *((unsigned int *)t208);
    t213 = (t212 != 0);
    if (t213 == 1)
        goto LAB89;

LAB90:
LAB91:    goto LAB80;

LAB83:    t193 = (t178 + 4);
    *((unsigned int *)t178) = 1;
    *((unsigned int *)t193) = 1;
    goto LAB84;

LAB85:    *((unsigned int *)t194) = 1;
    goto LAB88;

LAB87:    t201 = (t194 + 4);
    *((unsigned int *)t194) = 1;
    *((unsigned int *)t201) = 1;
    goto LAB88;

LAB89:    t214 = *((unsigned int *)t202);
    t215 = *((unsigned int *)t208);
    *((unsigned int *)t202) = (t214 | t215);
    t216 = (t161 + 4);
    t217 = (t194 + 4);
    t218 = *((unsigned int *)t216);
    t219 = (~(t218));
    t220 = *((unsigned int *)t161);
    t221 = (t220 & t219);
    t222 = *((unsigned int *)t217);
    t223 = (~(t222));
    t224 = *((unsigned int *)t194);
    t225 = (t224 & t223);
    t226 = (~(t221));
    t227 = (~(t225));
    t228 = *((unsigned int *)t208);
    *((unsigned int *)t208) = (t228 & t226);
    t229 = *((unsigned int *)t208);
    *((unsigned int *)t208) = (t229 & t227);
    goto LAB91;

LAB92:    xsi_set_current_line(54, ng0);
    t236 = ((char*)((ng2)));
    t237 = (t0 + 2696);
    xsi_vlogvar_assign_value(t237, t236, 0, 0, 1);
    goto LAB94;

LAB97:    xsi_set_current_line(60, ng0);
    t5 = (t0 + 608);
    t8 = *((char **)t5);
    t5 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t5, t8, 0, 0, 3, 0LL);
    goto LAB115;

LAB99:    xsi_set_current_line(61, ng0);
    t2 = (t0 + 880);
    t5 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t5, 0, 0, 3, 0LL);
    goto LAB115;

LAB101:    xsi_set_current_line(62, ng0);
    t2 = (t0 + 1288);
    t5 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t5, 0, 0, 3, 0LL);
    goto LAB115;

LAB103:    xsi_set_current_line(63, ng0);
    t2 = (t0 + 744);
    t5 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t5, 0, 0, 3, 0LL);
    goto LAB115;

LAB105:    xsi_set_current_line(64, ng0);
    t2 = (t0 + 472);
    t5 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t5, 0, 0, 3, 0LL);
    goto LAB115;

LAB107:    xsi_set_current_line(65, ng0);
    t2 = (t0 + 1016);
    t5 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t5, 0, 0, 3, 0LL);
    goto LAB115;

LAB109:    xsi_set_current_line(66, ng0);
    t2 = (t0 + 1424);
    t5 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t5, 0, 0, 3, 0LL);
    goto LAB115;

LAB111:    xsi_set_current_line(67, ng0);
    t2 = (t0 + 1152);
    t5 = *((char **)t2);
    t2 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t2, t5, 0, 0, 3, 0LL);
    goto LAB115;

LAB118:    t22 = (t6 + 4);
    *((unsigned int *)t6) = 1;
    *((unsigned int *)t22) = 1;
    goto LAB119;

LAB120:    *((unsigned int *)t35) = 1;
    goto LAB123;

LAB122:    t29 = (t35 + 4);
    *((unsigned int *)t35) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB123;

LAB124:    t32 = (t0 + 2856);
    t34 = (t32 + 56U);
    t40 = *((char **)t34);
    t42 = ((char*)((ng3)));
    memset(t41, 0, 8);
    t43 = (t40 + 4);
    t56 = (t42 + 4);
    t44 = *((unsigned int *)t40);
    t45 = *((unsigned int *)t42);
    t46 = (t44 ^ t45);
    t47 = *((unsigned int *)t43);
    t48 = *((unsigned int *)t56);
    t49 = (t47 ^ t48);
    t50 = (t46 | t49);
    t51 = *((unsigned int *)t43);
    t52 = *((unsigned int *)t56);
    t53 = (t51 | t52);
    t54 = (~(t53));
    t55 = (t50 & t54);
    if (t55 != 0)
        goto LAB130;

LAB127:    if (t53 != 0)
        goto LAB129;

LAB128:    *((unsigned int *)t41) = 1;

LAB130:    memset(t57, 0, 8);
    t64 = (t41 + 4);
    t59 = *((unsigned int *)t64);
    t60 = (~(t59));
    t61 = *((unsigned int *)t41);
    t62 = (t61 & t60);
    t63 = (t62 & 1U);
    if (t63 != 0)
        goto LAB131;

LAB132:    if (*((unsigned int *)t64) != 0)
        goto LAB133;

LAB134:    t66 = *((unsigned int *)t35);
    t67 = *((unsigned int *)t57);
    t68 = (t66 | t67);
    *((unsigned int *)t65) = t68;
    t70 = (t35 + 4);
    t71 = (t57 + 4);
    t79 = (t65 + 4);
    t72 = *((unsigned int *)t70);
    t73 = *((unsigned int *)t71);
    t74 = (t72 | t73);
    *((unsigned int *)t79) = t74;
    t75 = *((unsigned int *)t79);
    t76 = (t75 != 0);
    if (t76 == 1)
        goto LAB135;

LAB136:
LAB137:    goto LAB126;

LAB129:    t58 = (t41 + 4);
    *((unsigned int *)t41) = 1;
    *((unsigned int *)t58) = 1;
    goto LAB130;

LAB131:    *((unsigned int *)t57) = 1;
    goto LAB134;

LAB133:    t69 = (t57 + 4);
    *((unsigned int *)t57) = 1;
    *((unsigned int *)t69) = 1;
    goto LAB134;

LAB135:    t77 = *((unsigned int *)t65);
    t78 = *((unsigned int *)t79);
    *((unsigned int *)t65) = (t77 | t78);
    t80 = (t35 + 4);
    t93 = (t57 + 4);
    t81 = *((unsigned int *)t80);
    t82 = (~(t81));
    t83 = *((unsigned int *)t35);
    t33 = (t83 & t82);
    t84 = *((unsigned int *)t93);
    t85 = (~(t84));
    t86 = *((unsigned int *)t57);
    t87 = (t86 & t85);
    t88 = (~(t33));
    t89 = (~(t87));
    t90 = *((unsigned int *)t79);
    *((unsigned int *)t79) = (t90 & t88);
    t91 = *((unsigned int *)t79);
    *((unsigned int *)t79) = (t91 & t89);
    goto LAB137;

LAB138:    *((unsigned int *)t92) = 1;
    goto LAB141;

LAB140:    t100 = (t92 + 4);
    *((unsigned int *)t92) = 1;
    *((unsigned int *)t100) = 1;
    goto LAB141;

LAB142:    t106 = (t0 + 2856);
    t107 = (t106 + 56U);
    t108 = *((char **)t107);
    t110 = ((char*)((ng4)));
    memset(t109, 0, 8);
    t111 = (t108 + 4);
    t124 = (t110 + 4);
    t112 = *((unsigned int *)t108);
    t113 = *((unsigned int *)t110);
    t114 = (t112 ^ t113);
    t115 = *((unsigned int *)t111);
    t116 = *((unsigned int *)t124);
    t117 = (t115 ^ t116);
    t118 = (t114 | t117);
    t119 = *((unsigned int *)t111);
    t120 = *((unsigned int *)t124);
    t121 = (t119 | t120);
    t122 = (~(t121));
    t123 = (t118 & t122);
    if (t123 != 0)
        goto LAB148;

LAB145:    if (t121 != 0)
        goto LAB147;

LAB146:    *((unsigned int *)t109) = 1;

LAB148:    memset(t125, 0, 8);
    t132 = (t109 + 4);
    t127 = *((unsigned int *)t132);
    t128 = (~(t127));
    t129 = *((unsigned int *)t109);
    t130 = (t129 & t128);
    t131 = (t130 & 1U);
    if (t131 != 0)
        goto LAB149;

LAB150:    if (*((unsigned int *)t132) != 0)
        goto LAB151;

LAB152:    t134 = *((unsigned int *)t92);
    t135 = *((unsigned int *)t125);
    t136 = (t134 | t135);
    *((unsigned int *)t133) = t136;
    t138 = (t92 + 4);
    t139 = (t125 + 4);
    t147 = (t133 + 4);
    t140 = *((unsigned int *)t138);
    t141 = *((unsigned int *)t139);
    t142 = (t140 | t141);
    *((unsigned int *)t147) = t142;
    t143 = *((unsigned int *)t147);
    t144 = (t143 != 0);
    if (t144 == 1)
        goto LAB153;

LAB154:
LAB155:    goto LAB144;

LAB147:    t126 = (t109 + 4);
    *((unsigned int *)t109) = 1;
    *((unsigned int *)t126) = 1;
    goto LAB148;

LAB149:    *((unsigned int *)t125) = 1;
    goto LAB152;

LAB151:    t137 = (t125 + 4);
    *((unsigned int *)t125) = 1;
    *((unsigned int *)t137) = 1;
    goto LAB152;

LAB153:    t145 = *((unsigned int *)t133);
    t146 = *((unsigned int *)t147);
    *((unsigned int *)t133) = (t145 | t146);
    t148 = (t92 + 4);
    t162 = (t125 + 4);
    t149 = *((unsigned int *)t148);
    t150 = (~(t149));
    t151 = *((unsigned int *)t92);
    t152 = (t151 & t150);
    t153 = *((unsigned int *)t162);
    t154 = (~(t153));
    t155 = *((unsigned int *)t125);
    t156 = (t155 & t154);
    t157 = (~(t152));
    t158 = (~(t156));
    t159 = *((unsigned int *)t147);
    *((unsigned int *)t147) = (t159 & t157);
    t160 = *((unsigned int *)t147);
    *((unsigned int *)t147) = (t160 & t158);
    goto LAB155;

LAB156:    *((unsigned int *)t161) = 1;
    goto LAB159;

LAB158:    t169 = (t161 + 4);
    *((unsigned int *)t161) = 1;
    *((unsigned int *)t169) = 1;
    goto LAB159;

LAB160:    t175 = (t0 + 2856);
    t176 = (t175 + 56U);
    t177 = *((char **)t176);
    t179 = ((char*)((ng5)));
    memset(t178, 0, 8);
    t180 = (t177 + 4);
    t193 = (t179 + 4);
    t181 = *((unsigned int *)t177);
    t182 = *((unsigned int *)t179);
    t183 = (t181 ^ t182);
    t184 = *((unsigned int *)t180);
    t185 = *((unsigned int *)t193);
    t186 = (t184 ^ t185);
    t187 = (t183 | t186);
    t188 = *((unsigned int *)t180);
    t189 = *((unsigned int *)t193);
    t190 = (t188 | t189);
    t191 = (~(t190));
    t192 = (t187 & t191);
    if (t192 != 0)
        goto LAB166;

LAB163:    if (t190 != 0)
        goto LAB165;

LAB164:    *((unsigned int *)t178) = 1;

LAB166:    memset(t194, 0, 8);
    t201 = (t178 + 4);
    t196 = *((unsigned int *)t201);
    t197 = (~(t196));
    t198 = *((unsigned int *)t178);
    t199 = (t198 & t197);
    t200 = (t199 & 1U);
    if (t200 != 0)
        goto LAB167;

LAB168:    if (*((unsigned int *)t201) != 0)
        goto LAB169;

LAB170:    t203 = *((unsigned int *)t161);
    t204 = *((unsigned int *)t194);
    t205 = (t203 | t204);
    *((unsigned int *)t202) = t205;
    t207 = (t161 + 4);
    t208 = (t194 + 4);
    t216 = (t202 + 4);
    t209 = *((unsigned int *)t207);
    t210 = *((unsigned int *)t208);
    t211 = (t209 | t210);
    *((unsigned int *)t216) = t211;
    t212 = *((unsigned int *)t216);
    t213 = (t212 != 0);
    if (t213 == 1)
        goto LAB171;

LAB172:
LAB173:    goto LAB162;

LAB165:    t195 = (t178 + 4);
    *((unsigned int *)t178) = 1;
    *((unsigned int *)t195) = 1;
    goto LAB166;

LAB167:    *((unsigned int *)t194) = 1;
    goto LAB170;

LAB169:    t206 = (t194 + 4);
    *((unsigned int *)t194) = 1;
    *((unsigned int *)t206) = 1;
    goto LAB170;

LAB171:    t214 = *((unsigned int *)t202);
    t215 = *((unsigned int *)t216);
    *((unsigned int *)t202) = (t214 | t215);
    t217 = (t161 + 4);
    t230 = (t194 + 4);
    t218 = *((unsigned int *)t217);
    t219 = (~(t218));
    t220 = *((unsigned int *)t161);
    t221 = (t220 & t219);
    t222 = *((unsigned int *)t230);
    t223 = (~(t222));
    t224 = *((unsigned int *)t194);
    t225 = (t224 & t223);
    t226 = (~(t221));
    t227 = (~(t225));
    t228 = *((unsigned int *)t216);
    *((unsigned int *)t216) = (t228 & t226);
    t229 = *((unsigned int *)t216);
    *((unsigned int *)t216) = (t229 & t227);
    goto LAB173;

LAB174:    xsi_set_current_line(74, ng0);
    t237 = ((char*)((ng2)));
    t238 = (t0 + 2696);
    xsi_vlogvar_assign_value(t238, t237, 0, 0, 1);
    goto LAB176;

}


extern void work_m_00000000003405832742_3966510260_init()
{
	static char *pe[] = {(void *)Always_36_0};
	xsi_register_didat("work_m_00000000003405832742_3966510260", "isim/BGCounter_Test_isim_beh.exe.sim/work/m_00000000003405832742_3966510260.didat");
	xsi_register_executes(pe);
}
